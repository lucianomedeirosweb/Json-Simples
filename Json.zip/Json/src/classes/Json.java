package classes;

import org.json.JSONException;
import org.json.JSONObject;

public class Json {
	
	public static void main(String[] args)  throws JSONException{
		
	
			 // adicaoSimplesDeDados();
			adicaoDeUmObjeto();

		}
	
	

	
	
	private static void adicaoDeUmObjeto() throws JSONException {
         Carro carro = new Carro();
         carro.setId(1l);
         carro.setModelo("Celta");
         carro.setPlaca("KK");
         
         
         JSONObject  carroJson = new JSONObject();
         carroJson.put("Carro", carro);
         System.out.println(carroJson);
         
         
         				
	}



	private static void adicaoSimplesDeDados()throws JSONException {
		
		Carro carro = new Carro();
		carro.setId(1l);
		carro.setModelo("Celta");
		carro.setPlaca("255");
		
		// Cria��o do Objeto Json
		
		JSONObject carroJson = new JSONObject();
		carroJson.put("id", carro.getId());
		carroJson.put("Modelo", carro.getModelo());
		carroJson.put("Placa", carro.getPlaca());
		
		//Impres�o do objeto Json.
		System.out.println(carroJson);
		
		
	}
	
			
		
} 
